## NextPager
Go to next page of a forum by clicking a button or "Ctrl + Space", whatever you prefer!
## Installation (Firefox)
Addon Link: [NextPager](https://addons.mozilla.org/en-US/firefox/addon/goto_nextpage)
