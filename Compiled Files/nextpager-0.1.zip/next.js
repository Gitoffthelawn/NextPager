function updTab(tbs) {
    var tabUrl = tbs.url;
    var updUrl;
    if (tabUrl.indexOf("&page=") == -1) {
        // doesn't have a page num
        // first page
        // add page=2 and update
        updUrl = tabUrl + "&page=2";
        console.log("first " + updUrl);
    }
    else {
        // it already has a page num
        // get page num
        // increase it by 1
        var regTab = /(.*&page=)(\d+)/.exec(tabUrl);
        var pageNum = parseInt(regTab[2], 10);
        var baseUrl = regTab[1];
        updUrl = baseUrl + (pageNum+1).toString();
        console.log(updUrl);
    }
    browser.tabs.update(tbs.id, {url: updUrl});
}
function getCurTab(tbs) {
    var curTab = browser.tabs.get(tbs[0].id);
    curTab.then(updTab, logError);
}
function buttonClicked()
{
    // query tabs to get current tab
    var tabs = browser.tabs.query({currentWindow: true, active:true});
    tabs.then(getCurTab, logError);
}
function logError(err) {
    console.log(err);
}

// attaching function to listen to click in toolbar icon
browser.browserAction.onClicked.addListener(buttonClicked);